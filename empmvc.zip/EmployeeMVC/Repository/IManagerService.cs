﻿using EmployeeMVC.Models;

namespace EmployeeMVC.Repository
{
    public interface IManagerService
    {
        void AddManager(Manager m);
        List<Manager> DisplayManagers();
        void DeleteManager(int id);
        Manager FindManagerById(int id);
        void UpdateManager(Manager m);
    }
}

