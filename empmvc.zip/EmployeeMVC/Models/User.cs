﻿using System.ComponentModel.DataAnnotations;

namespace EmployeeMVC.Models
{
    public class User
    {
        [Key]
        public int Uid { get; set; }
        public string Uname { get; set; }
        public string? Email { get; set; }
        public string? Password { get; set; }
        public string Role { get; set; } // "Admin" or "Employee"
    }
}
