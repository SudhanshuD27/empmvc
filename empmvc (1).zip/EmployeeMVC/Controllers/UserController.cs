﻿using EmployeeMVC.Data;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeMVC.Controllers
{
    public class UserController : Controller
    {
        ApplicationDbContext db;

        public UserController(ApplicationDbContext db)
        {
            this.db = db;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(string email, string password)
        {
            var user = db.users.FirstOrDefault(u => u.Email == email && u.Password == password);

            if (user != null)
            {
                HttpContext.Session.SetInt32("Uid", user.Uid);
                HttpContext.Session.SetString("Role", user.Role);

                if (user.Role == "Admin")
                    return RedirectToAction("Admin", "Admin");

                if (user.Role == "Employee")
                    return RedirectToAction("UserList", "Document");
            }

            ViewBag.Msg = "Invalid email or password";
            return View();
        }
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }

    }

}
