﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EmployeeMVC.Models
{
    public class Emp
    {
        [Key]
        public int eid { get; set; }

        public string ename { get; set; }

        public string email { get; set; }

        public double esalary { get; set; }

        public string Ephoto { get; set; }

        [NotMapped]
        public IFormFile PhotoFile { get; set; }


        [ForeignKey("manager")]
        public int Mid { get; set; }
        public Manager manager { get; set; }

        [ForeignKey("department")]
        public int Did { get; set; }
        public Department department { get; set; }
    }
}

