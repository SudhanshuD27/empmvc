﻿using EmployeeMVC.Models;

namespace EmployeeMVC.Repository
{
    public interface IDepartmentService
    {
        void AddDepartment(Department d);
        List<Department> DisplayDepartments();
        void DeleteDepartment(int id);
        Department FindDepartmentById(int id);
        void UpdateDepartment(Department d);
    }
}

