﻿using System.ComponentModel.DataAnnotations;

namespace EmployeeMVC.Models
{
    public class Document
    {
        [Key]
        public int DocId { get; set; }

        public string Title { get; set; }

        public string FilePath { get; set; }

        public DateTime UploadedAt { get; set; }
    }
}
