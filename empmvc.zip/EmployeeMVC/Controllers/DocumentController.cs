﻿using EmployeeMVC.Data;
using EmployeeMVC.Models;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeMVC.Controllers
{
    public class DocumentController : Controller
    {
        ApplicationDbContext db;
        IWebHostEnvironment env;

        public DocumentController(ApplicationDbContext db, IWebHostEnvironment env)
        {
            this.db = db;
            this.env = env;
        }

        public IActionResult Upload()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Upload(string title, IFormFile file)
        {
            if (file != null && file.Length > 0)
            {
                string uploadsFolder = Path.Combine(env.WebRootPath, "uploads");
                if (!Directory.Exists(uploadsFolder))
                {
                    Directory.CreateDirectory(uploadsFolder);
                }

                string filePath = Path.Combine(uploadsFolder, file.FileName);
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    file.CopyTo(stream);
                }

                Document doc = new Document
                {
                    Title = title,
                    FilePath = "/uploads/" + file.FileName,
                    UploadedAt = DateTime.Now
                };

                db.Document.Add(doc);
                db.SaveChanges();
            }

            return RedirectToAction("AdminList");
        }

        public IActionResult AdminList()
        {
            var data = db.Document.ToList();
            return View(data);
        }

        public IActionResult UserList()
        {
            var data = db.Document.ToList();
            return View(data);
        }

        public IActionResult Delete(int id)
        {
            var doc = db.Document.Find(id);
            if (doc != null)
            {
                string filePath = Path.Combine(env.WebRootPath, doc.FilePath.TrimStart('/'));
                if (System.IO.File.Exists(filePath))
                {
                    System.IO.File.Delete(filePath);
                }

                db.Document.Remove(doc);
                db.SaveChanges();
            }
            return RedirectToAction("AdminList");
        }
    }
}
