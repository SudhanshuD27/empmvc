﻿using EmployeeMVC.Data;
using EmployeeMVC.Models;
using EmployeeMVC.Repository;

namespace EmployeeMVC.Service
{
    public class DepartmentService : IDepartmentService
    {
        ApplicationDbContext db;

        public DepartmentService(ApplicationDbContext db)
        {
            this.db = db;
        }

        public void AddDepartment(Department d)
        {
            db.Department.Add(d);
            db.SaveChanges();
        }

        public List<Department> DisplayDepartments()
        {
            return db.Department.ToList();
        }

        public void DeleteDepartment(int id)
        {
            var dept = db.Department.Find(id);
            db.Department.Remove(dept);
            db.SaveChanges();
        }

        public Department FindDepartmentById(int id)
        {
            return db.Department.Find(id);
        }

        public void UpdateDepartment(Department d)
        {
            db.Department.Update(d);
            db.SaveChanges();
        }
    }
}

