﻿using System.ComponentModel.DataAnnotations;

namespace EmployeeMVC.Models
{
    public class NewEmp
    {
        [Key]
        public int eid { get; set; }
        public string ename { get; set; }
        public string email { get; set; }
        public double esalary { get; set; }
    }
}
