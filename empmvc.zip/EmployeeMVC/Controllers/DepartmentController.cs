﻿using EmployeeMVC.Models;
using EmployeeMVC.Repository;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeMVC.Controllers
{
    public class DepartmentController : Controller
    {
        IDepartmentService dept;

        public DepartmentController(IDepartmentService dept)
        {
            this.dept = dept;
        }

        public IActionResult Index()
        {
            var data = dept.DisplayDepartments();
            return View(data);
        }

        public IActionResult AddDepartment()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddDepartment(Department d)
        {
            dept.AddDepartment(d);
            return RedirectToAction("Index");
        }

        public IActionResult DeleteDepartment(int id)
        {
            dept.DeleteDepartment(id);
            return RedirectToAction("Index");
        }

        public IActionResult EditDepartment(int id)
        {
            var data = dept.FindDepartmentById(id);
            return View(data);
        }

        [HttpPost]
        public IActionResult EditDepartment(Department d)
        {
            dept.UpdateDepartment(d);
            return RedirectToAction("Index");
        }
    }
}

