﻿using EmployeeMVC.Models;

namespace EmployeeMVC.Repository
{
    public interface IUserService
    {
        User ValidateUser(string email, string password);

    }
}
