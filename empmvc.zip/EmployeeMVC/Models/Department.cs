﻿using System.ComponentModel.DataAnnotations;

namespace EmployeeMVC.Models
{
    public class Department
    {
        [Key]
        public int Did { get; set; }

        public string Dname { get; set; }

        public List<Emp> emps { get; set; } 
    }
}

  