﻿using Microsoft.AspNetCore.Mvc;

namespace EmployeeMVC.Controllers
{
    public class AdminController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Admin()
        {
            return View();

        }
    }
}