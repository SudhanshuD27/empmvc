﻿using EmployeeMVC.Data;
using EmployeeMVC.Models;
using EmployeeMVC.Repository;

namespace EmployeeMVC.Service
{
    public class ManagerService : IManagerService
    {
        ApplicationDbContext db;

        public ManagerService(ApplicationDbContext db)
        {
            this.db = db;
        }

        public void AddManager(Manager m)
        {
            db.Manager.Add(m);
            db.SaveChanges();
        }

        public List<Manager> DisplayManagers()
        {
            return db.Manager.ToList();
        }

        public void DeleteManager(int id)
        {
            var data = db.Manager.Find(id);
            db.Manager.Remove(data);
            db.SaveChanges();
        }

        public Manager FindManagerById(int id)
        {
            return db.Manager.Find(id);
        }

        public void UpdateManager(Manager m)
        {
            db.Manager.Update(m);
            db.SaveChanges();
        }
    }
}
