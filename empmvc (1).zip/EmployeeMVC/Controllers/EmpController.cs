﻿using EmployeeMVC.Data;
using EmployeeMVC.Models;
using EmployeeMVC.Repository;
using EmployeeMVC.Service;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace EmployeeMVC.Controllers
{
    public class EmpController : Controller
    {
        ApplicationDbContext db;
        private readonly IEmpService EmpService;


        public EmpController(ApplicationDbContext db, IEmpService EmpService)
        {
            this.db = db;
            this.EmpService = EmpService; 
        }

        public IActionResult Index()
        {
            var data = db.employee.Include(e => e.manager).Include(e => e.department).ToList();
            return View(data);
        }

        [HttpPost]
        public IActionResult Index(string str)
        {
            if (!string.IsNullOrEmpty(str))
            {
                var data = db.employee
                    .Where(e => e.ename.Contains(str) || e.email.Contains(str) || e.esalary.ToString().Contains(str))
                    .Include(e => e.manager).Include(e => e.department)
                    .ToList();

                return View(data);
            }
            else
            {
                var data = db.employee.Include(e => e.manager).Include(e => e.department).ToList();
                return View(data);
            }
        }

        public IActionResult AddEmp()
        {
            ViewBag.managers = new SelectList(db.Manager.ToList(), "Mid", "Mname");
            ViewBag.departments = new SelectList(db.Department.ToList(), "Did", "Dname");
            return View();
        }

        [HttpPost]
        public IActionResult AddEmp(Emp e)
        {
            if (e.PhotoFile != null)
            {
                string folder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/images");
                if (!Directory.Exists(folder))
                {
                    Directory.CreateDirectory(folder);
                }

                string fileName = Guid.NewGuid().ToString() + Path.GetExtension(e.PhotoFile.FileName);
                string filePath = Path.Combine(folder, fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    e.PhotoFile.CopyTo(stream);
                }

                e.Ephoto = "/images/" + fileName;
            }

            EmpService.AddEmp(e);
            return RedirectToAction("Index");
        }

        public IActionResult DelEmp(int id)
        {
            var emp = db.employee.Find(id);
            if (emp != null)
            {
                db.employee.Remove(emp);
                db.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        public IActionResult EditEmp(int id)
        {
            var emp = db.employee.Find(id);
            ViewBag.managers = new SelectList(db.Manager.ToList(), "Mid", "Mname");
            ViewBag.departments = new SelectList(db.Department.ToList(), "Did", "Dname");
            return View(emp);
        }

        [HttpPost]
        public IActionResult EditEmp(Emp e)
        {
            db.employee.Update(e);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
