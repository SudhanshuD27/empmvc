﻿using System.ComponentModel.DataAnnotations;

namespace EmployeeMVC.Models
{
    public class Manager
    {
        [Key]
        public int Mid { get; set; }

        public string Mname { get; set; }

        public List<Emp> emps { get; set; }
    }
}
