﻿using EmployeeMVC.Models;
using Microsoft.EntityFrameworkCore;

namespace EmployeeMVC.Data
{
    public class ApplicationDbContext: DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }
        public DbSet<User> users { get; set; }
        public DbSet<Manager> Manager { get; set; }
        public DbSet<Department> Department { get; set; }
        public DbSet<Emp> employee { get; set; }
        public DbSet<Document> Document { get; set; }


    }

}
