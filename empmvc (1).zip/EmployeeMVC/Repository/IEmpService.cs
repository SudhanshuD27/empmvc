﻿using EmployeeMVC.Models;

namespace EmployeeMVC.Repository
{
    public interface IEmpService
    {
        void AddEmp(Emp e);
        List<Emp> DisplayEmp();
        void DeleteEmp(int id);
        Emp FindEmpById(int id);
        void UpdateEmp(Emp e);
    }
}
