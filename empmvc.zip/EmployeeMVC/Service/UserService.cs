﻿using EmployeeMVC.Data;
using EmployeeMVC.Models;
using EmployeeMVC.Repository;

namespace EmployeeMVC.Service
{
    public class UserService:IUserService
    {
        ApplicationDbContext db;

        public UserService(ApplicationDbContext db)
        {
            this.db = db;
        }

        public User ValidateUser(string email, string password)
        {
            return db.users.FirstOrDefault(u => u.Email == email && u.Password == password);
        }
    }
}

