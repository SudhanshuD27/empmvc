﻿using EmployeeMVC.Data;
using EmployeeMVC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace EmployeeMVC.Controllers
{
    public class EmpController : Controller
    {
        ApplicationDbContext db;

        public EmpController(ApplicationDbContext db)
        {
            this.db = db;
        }

        public IActionResult Index()
        {
            var data = db.employee.Include(e => e.manager).Include(e => e.department).ToList();
            return View(data);
        }

        [HttpPost]
        public IActionResult Index(string str)
        {
            if (!string.IsNullOrEmpty(str))
            {
                var data = db.employee
                    .Where(e => e.ename.Contains(str) || e.email.Contains(str) || e.esalary.ToString().Contains(str))
                    .Include(e => e.manager).Include(e => e.department)
                    .ToList();

                return View(data);
            }
            else
            {
                var data = db.employee.Include(e => e.manager).Include(e => e.department).ToList();
                return View(data);
            }
        }

        public IActionResult AddEmp()
        {
            ViewBag.managers = new SelectList(db.Manager.ToList(), "Mid", "Mname");
            ViewBag.departments = new SelectList(db.Department.ToList(), "Did", "Dname");
            return View();
        }

        [HttpPost]
        public IActionResult AddEmp(Emp e)
        {
            db.employee.Add(e);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult DelEmp(int id)
        {
            var emp = db.employee.Find(id);
            if (emp != null)
            {
                db.employee.Remove(emp);
                db.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        public IActionResult EditEmp(int id)
        {
            var emp = db.employee.Find(id);
            ViewBag.managers = new SelectList(db.Manager.ToList(), "Mid", "Mname");
            ViewBag.departments = new SelectList(db.Department.ToList(), "Did", "Dname");
            return View(emp);
        }

        [HttpPost]
        public IActionResult EditEmp(Emp e)
        {
            db.employee.Update(e);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
