﻿using EmployeeMVC.Data;
using EmployeeMVC.Models;
using EmployeeMVC.Repository;
using Microsoft.EntityFrameworkCore;

namespace EmployeeMVC.Service
{
    public class EmpService : IEmpService
    {
        ApplicationDbContext db;

        public EmpService(ApplicationDbContext db)
        {
            this.db = db;
        }

        public void AddEmp(Emp e)
        {
            db.employee.Add(e);
            db.SaveChanges();
        }

        public List<Emp> DisplayEmp()
        {
            return db.employee.Include(e => e.manager).Include(e => e.department).ToList();
        }

        public void DeleteEmp(int id)
        {
            var emp = db.employee.Find(id);
            db.employee.Remove(emp);
            db.SaveChanges();
        }

        public Emp FindEmpById(int id)
        {
            return db.employee.Find(id);
        }

        public void UpdateEmp(Emp e)
        {
            db.employee.Update(e);
            db.SaveChanges();
        }
    }
}

